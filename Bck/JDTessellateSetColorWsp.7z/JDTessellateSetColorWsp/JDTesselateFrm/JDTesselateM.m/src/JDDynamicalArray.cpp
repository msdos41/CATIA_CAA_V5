#include "JDDynamicalArray.h"
#include <iostream>
#include <stdexcept>
using namespace std;
//---------------------------------------------------------
JDDynamicalArray::JDDynamicalArray(const int& capcity)
:_size(0)
,_capacity(capcity)
{
	if (_capacity == 0)
	{
		_capacity = JDDynamicalArray::DEFAUL_CAP;
	}
	items = new int[_capacity];
}
//---------------------------------------------------------
JDDynamicalArray::~JDDynamicalArray()
{
	if(items != NULL)
	{
		delete[] items;
		items = NULL;
	}
}
//---------------------------------------------------------
void JDDynamicalArray::clear()
{
	_size = 0;
	_capacity = JDDynamicalArray::DEFAUL_CAP;
	if(items != NULL)
	{
		delete[] items;
		items = NULL;
	}
	items = new int[_capacity];
}
//---------------------------------------------------------
JDDynamicalArray::JDDynamicalArray(const JDDynamicalArray& other)
:_size(other._size)
,_capacity(other._capacity)
{
	items = new int[_capacity];
	std::memcpy(items, other.items, _size *sizeof(int));
	//for (int i = 0; i < _size; ++i)
	//{
	//	items[i] = other.items[i];
	//}
}
//---------------------------------------------------------
JDDynamicalArray& JDDynamicalArray::operator =(const JDDynamicalArray& other)
{
	if (&other != this)
	{
		_size = other._size;
		_capacity = other._capacity;
		delete[] items;
		items = new int[_capacity];
		std::memcpy(items, other.items, _size * sizeof(int));
	}
	return *this;
}
//---------------------------------------------------------
JDDynamicalArray::iterator JDDynamicalArray::begin()
{
	return items;
}
//---------------------------------------------------------
JDDynamicalArray::const_iterator JDDynamicalArray::begin() const
{
	return items;
}
//---------------------------------------------------------
JDDynamicalArray::iterator JDDynamicalArray::end()
{
	return items + _size;
}
//---------------------------------------------------------
JDDynamicalArray::const_iterator JDDynamicalArray::end() const
{
	return items + _size;
}
//---------------------------------------------------------
const int& JDDynamicalArray::operator [](const int& index)const
{
	if (index < 0 || _size <= index)
	{
		throw std::out_of_range("Array::operator[](const int&) const");
	}
	return items[index];
}
//---------------------------------------------------------
int& JDDynamicalArray::operator [](const int &index)
{
	if (index < 0 || _size <= index)
	{
		throw std::out_of_range("Array::operator[](const int&) const");
	}
	return items[index];
}
//---------------------------------------------------------
void JDDynamicalArray::insert(const int& index, const int& value)
{
	if (index < 0 || _size<= index)
	{
		throw std::out_of_range("Array::insert(const int&, const int&)"); 
	}
	if (_size < _capacity)
	{
		std::memmove(items + (index + 1), items + index, (_size - index) * sizeof(int));
		items[index] = value;
	}
	else
	{
		_capacity *= 2;
		int *tmp = new int[_capacity];
		std::memcpy(tmp, items, index * sizeof(int));
		std::memcpy(tmp + (index + 1), items + index, (_size - index) * sizeof(int));
		tmp[index] = value;
		delete[] items;
		items = tmp;
	}
	++_size;
}
//---------------------------------------------------------
void JDDynamicalArray::append(const int& value)
{
	if (_size < _capacity)
	{
		items[_size] = value;
	}
	else
	{
		_capacity *= 2;
		int *tmp = new int[_capacity];
		std::memcpy(tmp, items, _size * sizeof(int));
		tmp[_size] = value;

		delete[] items;
		items = tmp;
	}
	++_size;
}
//---------------------------------------------------------
void JDDynamicalArray::remove(const int& index)
{
	if (index < 0 || _size <= index)
	{
		throw std::out_of_range("Array::remove(const int&)");
	}
	--_size;
	if (index != _size)// _size already decreased.
	{
		memmove(items + index, items + (index + 1), (_size - index) * sizeof(int));
	}
	//    for (int i = index; i < _size; ++i) 
	//        items[i] = items[i + 1];
}
//---------------------------------------------------------
int JDDynamicalArray::size()const
{
	return _size;
}
//---------------------------------------------------------
int JDDynamicalArray::capacity()const
{
	return _capacity;
}
//---------------------------------------------------------
bool JDDynamicalArray::empty()const
{
	return 0 == _size;
}
//---------------------------------------------------------
void JDDynamicalArray::run()
{  
	char key;  
	int num;  
	cout<<"���������ѡ��:"<<"\t";  cin>>key;  
	while(key!='0')  
	{       
		switch(key)   
		{   
		case '1':
			{    
				cout<<"���������Ԫ�ص�λ��:\t";     
				cin>>num;     
				cout<<"���������Ԫ�ص�ֵ:\t";     
				cin>>key;     
				insert(num, key);     
				break;   
			}
		case '2':
			{     
				cout<<"������׷��Ԫ�ص�ֵ:\t";     
				cin>>key;     
				append(key);    
				break;    
			}
		case '3':
			{    
				cout<<"��̬����Ĵ�СΪ:\t"<<size()<<endl;    
				break;   
			}
		case '4':
			{   
				cout<<"��̬���������Ϊ:\t"<<capacity()<<endl;   
				break; 
			}
		case '5':
			{    
				cout<<"����������ɾ����Ԫ�ص�λ��:\t";   
				cin>>num;  
				remove(num);   
				break;  
			}          
		default:break;   
		}   
		cout<<"���������ѡ��:"<<"\t";   
		cin>>key;
	}
}
//---------------------------------------------------------




//---------------------------------------------------------
//#define INIT_DATA_NUM 10 
//
////576929242@qq.com
//
////---------------------------------------------------------
//JDDynamicalArray::JDDynamicalArray(void)
//{
//	iCount = 0;
//	pData = NULL;
//}
////---------------------------------------------------------
//JDDynamicalArray::~JDDynamicalArray(void)
//{
//	free(pData );
//	pData = NULL;
//}
////---------------------------------------------------------
//bool JDDynamicalArray::initArray(int size)
//{
//	int initSize = (size < 0) ? size:INIT_DATA_NUM;
//	pData = ( elem_t * )malloc( initSize * sizeof( elem_t) );
//	if (pData != NULL)
//	{
//		iCapacity = initSize;
//		iCount ++;
//		return true;
//	}
//	return false;
//}
////---------------------------------------------------------
//bool JDDynamicalArray::setValue(int index, elem_t val )
//{
//	if (index >= 0 && index < iCount)
//	{
//		pData[index] = val;
//		return true;
//	}
//	return false;
//}
////---------------------------------------------------------
//elem_t* JDDynamicalArray::getRef(int index )
//{
//	elem_t * eRet = NULL;
//	if( index > 0 && index < iCount )
//	{
//		eRet = pData + index;
//	}
//	return eRet;
//}
////---------------------------------------------------------
//elem_t JDDynamicalArray::getValue(int index )
//{
//	return pData[index];
//}
////---------------------------------------------------------
//bool JDDynamicalArray::destroyArray()
//{
//	free(pData);
//	pData = NULL;
//	return true;
//}
