#ifdef  _WINDOWS_SOURCE
#ifdef  __JDTesselateM
#define ExportedByJDTesselateM     __declspec(dllexport)
#else
#define ExportedByJDTesselateM     __declspec(dllimport)
#endif
#else
#define ExportedByJDTesselateM
#endif
