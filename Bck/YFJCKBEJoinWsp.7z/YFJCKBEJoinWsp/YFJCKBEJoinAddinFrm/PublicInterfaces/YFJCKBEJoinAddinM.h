#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinAddinM
#define ExportedByYFJCKBEJoinAddinM     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinAddinM     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinAddinM
#endif
