#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinCatalogM
#define ExportedByYFJCKBEJoinCatalogM     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinCatalogM     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinCatalogM
#endif
