#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinImpM
#define ExportedByYFJCKBEJoinImpM     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinImpM     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinImpM
#endif
