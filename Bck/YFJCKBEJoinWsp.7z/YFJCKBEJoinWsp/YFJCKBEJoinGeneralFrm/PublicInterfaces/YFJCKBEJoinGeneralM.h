#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinGeneralM
#define ExportedByYFJCKBEJoinGeneralM     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinGeneralM     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinGeneralM
#endif
