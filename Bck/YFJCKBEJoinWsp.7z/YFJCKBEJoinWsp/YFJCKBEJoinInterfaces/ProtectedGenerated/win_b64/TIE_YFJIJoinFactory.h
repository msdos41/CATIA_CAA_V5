#ifndef __TIE_YFJIJoinFactory
#define __TIE_YFJIJoinFactory

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "YFJIJoinFactory.h"
#include "JS0DSPA.h"


#ifdef _WINDOWS_SOURCE
#define Exported __declspec(dllexport)
#define Imported __declspec(dllimport)
#else
#define Exported 
#define Imported 
#endif


/* To link an implementation with the interface YFJIJoinFactory */
#define declare_TIE_YFJIJoinFactory(classe) \
 \
 \
class TIEYFJIJoinFactory##classe : public YFJIJoinFactory \
{ \
   private: \
      CATDeclareCommonTIEMembers \
   public: \
      CATDeclareTIEMethods(YFJIJoinFactory, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareIDispatchMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual YFJIJoinGMAW  * CreateGMAWWeldingSpot(CATISpecObject_var iRefEle) ; \
};



#define ENVTIEdeclare_YFJIJoinFactory(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual YFJIJoinGMAW  * CreateGMAWWeldingSpot(CATISpecObject_var iRefEle) ; \


#define ENVTIEdefine_YFJIJoinFactory(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
YFJIJoinGMAW  *  ENVTIEName::CreateGMAWWeldingSpot(CATISpecObject_var iRefEle)  \
{ \
return (ENVTIECALL(YFJIJoinFactory,ENVTIETypeLetter,ENVTIELetter)CreateGMAWWeldingSpot(iRefEle)); \
} \


/* Name of the TIE class */
#define class_TIE_YFJIJoinFactory(classe)    TIEYFJIJoinFactory##classe


/* Common methods inside a TIE */
#define common_TIE_YFJIJoinFactory(classe) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers(YFJIJoinFactory, classe) \
 \
 \
CATImplementTIEMethods(YFJIJoinFactory, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(YFJIJoinFactory, classe, 1) \
CATImplementIDispatchMethodsForCATBaseUnknownTIE(YFJIJoinFactory, classe) \
CATImplementCATBaseUnknownMethodsForTIE(YFJIJoinFactory, classe) \
 \
YFJIJoinGMAW  *  TIEYFJIJoinFactory##classe::CreateGMAWWeldingSpot(CATISpecObject_var iRefEle)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->CreateGMAWWeldingSpot(iRefEle)); \
} \



/* Macro used to link an implementation with an interface */
#define TIE_YFJIJoinFactory(classe) \
 \
 \
declare_TIE_YFJIJoinFactory(classe) \
 \
 \
CATMetaClass * __stdcall TIEYFJIJoinFactory##classe::MetaObject() \
{ \
   if (!meta_object) \
   { \
      meta_object=new CATMetaClass(&IID_YFJIJoinFactory,"YFJIJoinFactory",YFJIJoinFactory::MetaObject(),classe::MetaObject(),TIE); \
   } \
   return(meta_object); \
} \
 \
 \
common_TIE_YFJIJoinFactory(classe) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(YFJIJoinFactory, classe) \
 \
/* to put information into the dictionary */ \
static CATFillDictionary DicYFJIJoinFactory##classe(classe::MetaObject(),YFJIJoinFactory::MetaObject(),(void *)CreateTIEYFJIJoinFactory##classe)



/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define TIEchain_YFJIJoinFactory(classe) \
 \
 \
declare_TIE_YFJIJoinFactory(classe) \
 \
 \
CATMetaClass * __stdcall TIEYFJIJoinFactory##classe::MetaObject() \
{ \
   if (!meta_object) \
   { \
      meta_object=new CATMetaClass(&IID_YFJIJoinFactory,"YFJIJoinFactory",YFJIJoinFactory::MetaObject(),classe::MetaObject(),TIEchain); \
   } \
   return(meta_object); \
} \
 \
 \
common_TIE_YFJIJoinFactory(classe) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(YFJIJoinFactory, classe) \
 \
/* to put information into the dictionary */ \
static CATFillDictionary DicYFJIJoinFactory##classe(classe::MetaObject(),YFJIJoinFactory::MetaObject(),(void *)CreateTIEYFJIJoinFactory##classe)


/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_YFJIJoinFactory(classe) TIE_YFJIJoinFactory(classe)
#else
#define BOA_YFJIJoinFactory(classe) CATImplementBOA(YFJIJoinFactory, classe)
#endif

#endif
