#ifndef __TIE_YFJIJoinGMAW
#define __TIE_YFJIJoinGMAW

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "YFJIJoinGMAW.h"
#include "JS0DSPA.h"


#ifdef _WINDOWS_SOURCE
#define Exported __declspec(dllexport)
#define Imported __declspec(dllimport)
#else
#define Exported 
#define Imported 
#endif


/* To link an implementation with the interface YFJIJoinGMAW */
#define declare_TIE_YFJIJoinGMAW(classe) \
 \
 \
class TIEYFJIJoinGMAW##classe : public YFJIJoinGMAW \
{ \
   private: \
      CATDeclareCommonTIEMembers \
   public: \
      CATDeclareTIEMethods(YFJIJoinGMAW, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareIDispatchMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual HRESULT SetWeldingSpotName(CATUnicodeString iName) ; \
      virtual HRESULT GetWeldingSpotName(CATUnicodeString &oName) ; \
      virtual HRESULT SetSerialNumber(CATUnicodeString iName) ; \
      virtual HRESULT GetSerialNumber(CATUnicodeString &oName) ; \
      virtual HRESULT SetType(CATUnicodeString iName) ; \
      virtual HRESULT GetType(CATUnicodeString &oName) ; \
      virtual HRESULT SetTypeLevel (CATUnicodeString  iName) ; \
      virtual HRESULT GetTypeLevel (CATUnicodeString & oName) ; \
      virtual HRESULT SetJoinShape (CATUnicodeString  iName ) ; \
      virtual HRESULT GetJoinShape (CATUnicodeString  &oName ) ; \
      virtual HRESULT SetDiameter(double iValue) ; \
      virtual HRESULT GetDiameter(double &oValue) ; \
      virtual HRESULT SetRefGeoEle(CATISpecObject_var iRefEle) ; \
      virtual HRESULT GetRefGeoEle(CATISpecObject_var &oRefEle) ; \
      virtual HRESULT SetRefCurveLength(double iLength) ; \
      virtual HRESULT GetRefCurveLength(double &oLength) ; \
      virtual HRESULT SetRefCoordMiddle(CATListOfDouble iValue) ; \
      virtual HRESULT GetRefCoordMiddle(CATListOfDouble &oValue) ; \
      virtual HRESULT SetRefCoordStart(CATListOfDouble iValue) ; \
      virtual HRESULT GetRefCoordStart(CATListOfDouble &oValue) ; \
      virtual HRESULT SetRefCoordEnd(CATListOfDouble iValue) ; \
      virtual HRESULT GetRefCoordEnd(CATListOfDouble &oValue) ; \
      virtual HRESULT SetRefVector (CATListOfDouble  iValue) ; \
      virtual HRESULT GetRefVector (CATListOfDouble & oValue) ; \
      virtual HRESULT SetWeldFilletHeight (double  iValue) ; \
      virtual HRESULT GetWeldFilletHeight (double & oValue) ; \
      virtual HRESULT SetConnectorThickness (CATListOfDouble  iValue) ; \
      virtual HRESULT GetConnectorThickness (CATListOfDouble & oValue) ; \
      virtual HRESULT SetSelfWeld (CATBoolean  iSelfWeld ) ; \
      virtual HRESULT GetSelfWeld (CATBoolean  &oSelfWeld ) ; \
      virtual HRESULT SetRGBR(int iValue) ; \
      virtual HRESULT GetRGBR(int &oValue) ; \
      virtual HRESULT SetRGBG(int iValue) ; \
      virtual HRESULT GetRGBG(int &oValue) ; \
      virtual HRESULT SetRGBB(int iValue) ; \
      virtual HRESULT GetRGBB(int &oValue) ; \
      virtual  HRESULT SetJoinType(int iValue) ; \
      virtual  HRESULT GetJoinType(int &oValue) ; \
      virtual  HRESULT SetConnectorPartNumber (CATListOfCATUnicodeString iValue) ; \
      virtual  HRESULT GetConnectorPartNumber (CATListOfCATUnicodeString & oValue) ; \
      virtual HRESULT SetConnectorExternal(CATListValCATISpecObject_var iLstSpecObjects) ; \
      virtual HRESULT GetConnectorExternal (CATListValCATISpecObject_var &oLstSpecObjects) ; \
      virtual HRESULT SetConnectorObject(CATListValCATISpecObject_var iLstSpecObjects) ; \
      virtual HRESULT GetConnectorObject (CATListValCATISpecObject_var &oLstSpecObjects) ; \
};



#define ENVTIEdeclare_YFJIJoinGMAW(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual HRESULT SetWeldingSpotName(CATUnicodeString iName) ; \
virtual HRESULT GetWeldingSpotName(CATUnicodeString &oName) ; \
virtual HRESULT SetSerialNumber(CATUnicodeString iName) ; \
virtual HRESULT GetSerialNumber(CATUnicodeString &oName) ; \
virtual HRESULT SetType(CATUnicodeString iName) ; \
virtual HRESULT GetType(CATUnicodeString &oName) ; \
virtual HRESULT SetTypeLevel (CATUnicodeString  iName) ; \
virtual HRESULT GetTypeLevel (CATUnicodeString & oName) ; \
virtual HRESULT SetJoinShape (CATUnicodeString  iName ) ; \
virtual HRESULT GetJoinShape (CATUnicodeString  &oName ) ; \
virtual HRESULT SetDiameter(double iValue) ; \
virtual HRESULT GetDiameter(double &oValue) ; \
virtual HRESULT SetRefGeoEle(CATISpecObject_var iRefEle) ; \
virtual HRESULT GetRefGeoEle(CATISpecObject_var &oRefEle) ; \
virtual HRESULT SetRefCurveLength(double iLength) ; \
virtual HRESULT GetRefCurveLength(double &oLength) ; \
virtual HRESULT SetRefCoordMiddle(CATListOfDouble iValue) ; \
virtual HRESULT GetRefCoordMiddle(CATListOfDouble &oValue) ; \
virtual HRESULT SetRefCoordStart(CATListOfDouble iValue) ; \
virtual HRESULT GetRefCoordStart(CATListOfDouble &oValue) ; \
virtual HRESULT SetRefCoordEnd(CATListOfDouble iValue) ; \
virtual HRESULT GetRefCoordEnd(CATListOfDouble &oValue) ; \
virtual HRESULT SetRefVector (CATListOfDouble  iValue) ; \
virtual HRESULT GetRefVector (CATListOfDouble & oValue) ; \
virtual HRESULT SetWeldFilletHeight (double  iValue) ; \
virtual HRESULT GetWeldFilletHeight (double & oValue) ; \
virtual HRESULT SetConnectorThickness (CATListOfDouble  iValue) ; \
virtual HRESULT GetConnectorThickness (CATListOfDouble & oValue) ; \
virtual HRESULT SetSelfWeld (CATBoolean  iSelfWeld ) ; \
virtual HRESULT GetSelfWeld (CATBoolean  &oSelfWeld ) ; \
virtual HRESULT SetRGBR(int iValue) ; \
virtual HRESULT GetRGBR(int &oValue) ; \
virtual HRESULT SetRGBG(int iValue) ; \
virtual HRESULT GetRGBG(int &oValue) ; \
virtual HRESULT SetRGBB(int iValue) ; \
virtual HRESULT GetRGBB(int &oValue) ; \
virtual  HRESULT SetJoinType(int iValue) ; \
virtual  HRESULT GetJoinType(int &oValue) ; \
virtual  HRESULT SetConnectorPartNumber (CATListOfCATUnicodeString iValue) ; \
virtual  HRESULT GetConnectorPartNumber (CATListOfCATUnicodeString & oValue) ; \
virtual HRESULT SetConnectorExternal(CATListValCATISpecObject_var iLstSpecObjects) ; \
virtual HRESULT GetConnectorExternal (CATListValCATISpecObject_var &oLstSpecObjects) ; \
virtual HRESULT SetConnectorObject(CATListValCATISpecObject_var iLstSpecObjects) ; \
virtual HRESULT GetConnectorObject (CATListValCATISpecObject_var &oLstSpecObjects) ; \


#define ENVTIEdefine_YFJIJoinGMAW(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
HRESULT  ENVTIEName::SetWeldingSpotName(CATUnicodeString iName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetWeldingSpotName(iName)); \
} \
HRESULT  ENVTIEName::GetWeldingSpotName(CATUnicodeString &oName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetWeldingSpotName(oName)); \
} \
HRESULT  ENVTIEName::SetSerialNumber(CATUnicodeString iName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetSerialNumber(iName)); \
} \
HRESULT  ENVTIEName::GetSerialNumber(CATUnicodeString &oName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetSerialNumber(oName)); \
} \
HRESULT  ENVTIEName::SetType(CATUnicodeString iName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetType(iName)); \
} \
HRESULT  ENVTIEName::GetType(CATUnicodeString &oName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetType(oName)); \
} \
HRESULT  ENVTIEName::SetTypeLevel (CATUnicodeString  iName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetTypeLevel (iName)); \
} \
HRESULT  ENVTIEName::GetTypeLevel (CATUnicodeString & oName)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetTypeLevel (oName)); \
} \
HRESULT  ENVTIEName::SetJoinShape (CATUnicodeString  iName )  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetJoinShape (iName )); \
} \
HRESULT  ENVTIEName::GetJoinShape (CATUnicodeString  &oName )  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetJoinShape (oName )); \
} \
HRESULT  ENVTIEName::SetDiameter(double iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetDiameter(iValue)); \
} \
HRESULT  ENVTIEName::GetDiameter(double &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetDiameter(oValue)); \
} \
HRESULT  ENVTIEName::SetRefGeoEle(CATISpecObject_var iRefEle)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefGeoEle(iRefEle)); \
} \
HRESULT  ENVTIEName::GetRefGeoEle(CATISpecObject_var &oRefEle)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefGeoEle(oRefEle)); \
} \
HRESULT  ENVTIEName::SetRefCurveLength(double iLength)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefCurveLength(iLength)); \
} \
HRESULT  ENVTIEName::GetRefCurveLength(double &oLength)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefCurveLength(oLength)); \
} \
HRESULT  ENVTIEName::SetRefCoordMiddle(CATListOfDouble iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefCoordMiddle(iValue)); \
} \
HRESULT  ENVTIEName::GetRefCoordMiddle(CATListOfDouble &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefCoordMiddle(oValue)); \
} \
HRESULT  ENVTIEName::SetRefCoordStart(CATListOfDouble iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefCoordStart(iValue)); \
} \
HRESULT  ENVTIEName::GetRefCoordStart(CATListOfDouble &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefCoordStart(oValue)); \
} \
HRESULT  ENVTIEName::SetRefCoordEnd(CATListOfDouble iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefCoordEnd(iValue)); \
} \
HRESULT  ENVTIEName::GetRefCoordEnd(CATListOfDouble &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefCoordEnd(oValue)); \
} \
HRESULT  ENVTIEName::SetRefVector (CATListOfDouble  iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRefVector (iValue)); \
} \
HRESULT  ENVTIEName::GetRefVector (CATListOfDouble & oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRefVector (oValue)); \
} \
HRESULT  ENVTIEName::SetWeldFilletHeight (double  iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetWeldFilletHeight (iValue)); \
} \
HRESULT  ENVTIEName::GetWeldFilletHeight (double & oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetWeldFilletHeight (oValue)); \
} \
HRESULT  ENVTIEName::SetConnectorThickness (CATListOfDouble  iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetConnectorThickness (iValue)); \
} \
HRESULT  ENVTIEName::GetConnectorThickness (CATListOfDouble & oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetConnectorThickness (oValue)); \
} \
HRESULT  ENVTIEName::SetSelfWeld (CATBoolean  iSelfWeld )  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetSelfWeld (iSelfWeld )); \
} \
HRESULT  ENVTIEName::GetSelfWeld (CATBoolean  &oSelfWeld )  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetSelfWeld (oSelfWeld )); \
} \
HRESULT  ENVTIEName::SetRGBR(int iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRGBR(iValue)); \
} \
HRESULT  ENVTIEName::GetRGBR(int &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRGBR(oValue)); \
} \
HRESULT  ENVTIEName::SetRGBG(int iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRGBG(iValue)); \
} \
HRESULT  ENVTIEName::GetRGBG(int &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRGBG(oValue)); \
} \
HRESULT  ENVTIEName::SetRGBB(int iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetRGBB(iValue)); \
} \
HRESULT  ENVTIEName::GetRGBB(int &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetRGBB(oValue)); \
} \
HRESULT  ENVTIEName::SetJoinType(int iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetJoinType(iValue)); \
} \
HRESULT  ENVTIEName::GetJoinType(int &oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetJoinType(oValue)); \
} \
HRESULT  ENVTIEName::SetConnectorPartNumber (CATListOfCATUnicodeString iValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetConnectorPartNumber (iValue)); \
} \
HRESULT  ENVTIEName::GetConnectorPartNumber (CATListOfCATUnicodeString & oValue)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetConnectorPartNumber (oValue)); \
} \
HRESULT  ENVTIEName::SetConnectorExternal(CATListValCATISpecObject_var iLstSpecObjects)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetConnectorExternal(iLstSpecObjects)); \
} \
HRESULT  ENVTIEName::GetConnectorExternal (CATListValCATISpecObject_var &oLstSpecObjects)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetConnectorExternal (oLstSpecObjects)); \
} \
HRESULT  ENVTIEName::SetConnectorObject(CATListValCATISpecObject_var iLstSpecObjects)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)SetConnectorObject(iLstSpecObjects)); \
} \
HRESULT  ENVTIEName::GetConnectorObject (CATListValCATISpecObject_var &oLstSpecObjects)  \
{ \
return (ENVTIECALL(YFJIJoinGMAW,ENVTIETypeLetter,ENVTIELetter)GetConnectorObject (oLstSpecObjects)); \
} \


/* Name of the TIE class */
#define class_TIE_YFJIJoinGMAW(classe)    TIEYFJIJoinGMAW##classe


/* Common methods inside a TIE */
#define common_TIE_YFJIJoinGMAW(classe) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers(YFJIJoinGMAW, classe) \
 \
 \
CATImplementTIEMethods(YFJIJoinGMAW, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(YFJIJoinGMAW, classe, 1) \
CATImplementIDispatchMethodsForCATBaseUnknownTIE(YFJIJoinGMAW, classe) \
CATImplementCATBaseUnknownMethodsForTIE(YFJIJoinGMAW, classe) \
 \
HRESULT  TIEYFJIJoinGMAW##classe::SetWeldingSpotName(CATUnicodeString iName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetWeldingSpotName(iName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetWeldingSpotName(CATUnicodeString &oName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetWeldingSpotName(oName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetSerialNumber(CATUnicodeString iName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetSerialNumber(iName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetSerialNumber(CATUnicodeString &oName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetSerialNumber(oName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetType(CATUnicodeString iName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetType(iName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetType(CATUnicodeString &oName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetType(oName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetTypeLevel (CATUnicodeString  iName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetTypeLevel (iName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetTypeLevel (CATUnicodeString & oName)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetTypeLevel (oName)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetJoinShape (CATUnicodeString  iName )  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetJoinShape (iName )); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetJoinShape (CATUnicodeString  &oName )  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetJoinShape (oName )); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetDiameter(double iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetDiameter(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetDiameter(double &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetDiameter(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefGeoEle(CATISpecObject_var iRefEle)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefGeoEle(iRefEle)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefGeoEle(CATISpecObject_var &oRefEle)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefGeoEle(oRefEle)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefCurveLength(double iLength)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefCurveLength(iLength)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefCurveLength(double &oLength)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefCurveLength(oLength)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefCoordMiddle(CATListOfDouble iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefCoordMiddle(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefCoordMiddle(CATListOfDouble &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefCoordMiddle(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefCoordStart(CATListOfDouble iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefCoordStart(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefCoordStart(CATListOfDouble &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefCoordStart(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefCoordEnd(CATListOfDouble iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefCoordEnd(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefCoordEnd(CATListOfDouble &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefCoordEnd(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRefVector (CATListOfDouble  iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRefVector (iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRefVector (CATListOfDouble & oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRefVector (oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetWeldFilletHeight (double  iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetWeldFilletHeight (iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetWeldFilletHeight (double & oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetWeldFilletHeight (oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetConnectorThickness (CATListOfDouble  iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetConnectorThickness (iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetConnectorThickness (CATListOfDouble & oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetConnectorThickness (oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetSelfWeld (CATBoolean  iSelfWeld )  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetSelfWeld (iSelfWeld )); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetSelfWeld (CATBoolean  &oSelfWeld )  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetSelfWeld (oSelfWeld )); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRGBR(int iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRGBR(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRGBR(int &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRGBR(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRGBG(int iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRGBG(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRGBG(int &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRGBG(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetRGBB(int iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetRGBB(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetRGBB(int &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetRGBB(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetJoinType(int iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetJoinType(iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetJoinType(int &oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetJoinType(oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetConnectorPartNumber (CATListOfCATUnicodeString iValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetConnectorPartNumber (iValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetConnectorPartNumber (CATListOfCATUnicodeString & oValue)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetConnectorPartNumber (oValue)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetConnectorExternal(CATListValCATISpecObject_var iLstSpecObjects)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetConnectorExternal(iLstSpecObjects)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetConnectorExternal (CATListValCATISpecObject_var &oLstSpecObjects)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetConnectorExternal (oLstSpecObjects)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::SetConnectorObject(CATListValCATISpecObject_var iLstSpecObjects)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->SetConnectorObject(iLstSpecObjects)); \
} \
HRESULT  TIEYFJIJoinGMAW##classe::GetConnectorObject (CATListValCATISpecObject_var &oLstSpecObjects)  \
{ \
   return(((classe *)Tie_Method(NecessaryData.ForTIE,ptstat))->GetConnectorObject (oLstSpecObjects)); \
} \



/* Macro used to link an implementation with an interface */
#define TIE_YFJIJoinGMAW(classe) \
 \
 \
declare_TIE_YFJIJoinGMAW(classe) \
 \
 \
CATMetaClass * __stdcall TIEYFJIJoinGMAW##classe::MetaObject() \
{ \
   if (!meta_object) \
   { \
      meta_object=new CATMetaClass(&IID_YFJIJoinGMAW,"YFJIJoinGMAW",YFJIJoinGMAW::MetaObject(),classe::MetaObject(),TIE); \
   } \
   return(meta_object); \
} \
 \
 \
common_TIE_YFJIJoinGMAW(classe) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(YFJIJoinGMAW, classe) \
 \
/* to put information into the dictionary */ \
static CATFillDictionary DicYFJIJoinGMAW##classe(classe::MetaObject(),YFJIJoinGMAW::MetaObject(),(void *)CreateTIEYFJIJoinGMAW##classe)



/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define TIEchain_YFJIJoinGMAW(classe) \
 \
 \
declare_TIE_YFJIJoinGMAW(classe) \
 \
 \
CATMetaClass * __stdcall TIEYFJIJoinGMAW##classe::MetaObject() \
{ \
   if (!meta_object) \
   { \
      meta_object=new CATMetaClass(&IID_YFJIJoinGMAW,"YFJIJoinGMAW",YFJIJoinGMAW::MetaObject(),classe::MetaObject(),TIEchain); \
   } \
   return(meta_object); \
} \
 \
 \
common_TIE_YFJIJoinGMAW(classe) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(YFJIJoinGMAW, classe) \
 \
/* to put information into the dictionary */ \
static CATFillDictionary DicYFJIJoinGMAW##classe(classe::MetaObject(),YFJIJoinGMAW::MetaObject(),(void *)CreateTIEYFJIJoinGMAW##classe)


/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_YFJIJoinGMAW(classe) TIE_YFJIJoinGMAW(classe)
#else
#define BOA_YFJIJoinGMAW(classe) CATImplementBOA(YFJIJoinGMAW, classe)
#endif

#endif
