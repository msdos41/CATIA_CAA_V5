#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinItfCPP
#define ExportedByYFJCKBEJoinItfCPP     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinItfCPP     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinItfCPP
#endif
