#include "YFJIJoinFactory.h"

#ifndef LOCAL_DEFINITION_FOR_IID
IID IID_YFJIJoinFactory = { 0xfdf66b56, 0x9e21, 0x48cf, { 0x8d, 0x58, 0x5a, 0x17, 0x39, 0x05, 0x0b, 0x07} };
#endif

CATImplementInterface(YFJIJoinFactory, CATBaseUnknown);
CATImplementHandler(YFJIJoinFactory, CATBaseUnknown);
