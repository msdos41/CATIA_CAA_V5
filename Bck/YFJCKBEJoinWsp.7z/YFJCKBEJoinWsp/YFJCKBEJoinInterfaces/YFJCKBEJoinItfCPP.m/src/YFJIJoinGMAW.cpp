#include "YFJIJoinGMAW.h"

#ifndef LOCAL_DEFINITION_FOR_IID
IID IID_YFJIJoinGMAW = { 0x3bde1888, 0xbaa4, 0x49ff, { 0xad, 0x34, 0xbd, 0xb8, 0xdd, 0xf3, 0x30, 0x8a} };
#endif

CATImplementInterface(YFJIJoinGMAW, CATBaseUnknown);
CATImplementHandler(YFJIJoinGMAW, CATBaseUnknown);
