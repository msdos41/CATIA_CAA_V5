#ifdef  _WINDOWS_SOURCE
#ifdef  __YFJCKBEJoinUIM
#define ExportedByYFJCKBEJoinUIM     __declspec(dllexport)
#else
#define ExportedByYFJCKBEJoinUIM     __declspec(dllimport)
#endif
#else
#define ExportedByYFJCKBEJoinUIM
#endif
