/*
 * =====================================================================================
 *
 *       Filename:  hglm_lic_lib.h
 *
 *    Description:  api for outside
 *
 *        Version:  1.2
 *        Created:  2015-06-24
 *       Revision:  none
 *       Compiler:  gcc&msvc
 *
 *         Author:  zhaobang(XBon), zhaobang@huiguantech.com
 *        Company:  HG
 *
 * =====================================================================================
 */

#ifndef _HGLM_LIC_LIB_H_
#define _HGLM_LIC_LIB_H_

//#define DLL

#ifdef __cplusplus
extern "C" {
#endif

#ifdef DLL
int __declspec(dllexport)hglm_set_config_index(char* theConfigIndex);
int __declspec(dllexport)hglm_set_env_var(char* theEnvVar);
int __declspec(dllexport)hglm_set_client_code(char* theClientCode);
int __declspec(dllexport)hglm_request(char* featureName, char* featureVersion, int licReqNums);
int __declspec(dllexport)hglm_keep(char* featureName, char* featureVersion);
int __declspec(dllexport)hglm_release(char* featureName, char* featureVersion);

#else
int hglm_set_config_index(char* theConfigIndex);
int hglm_set_env_var(char* theEnvVar);
int hglm_set_client_code(char* theClientCode);
int hglm_request(char* featureName, char* featureVersion, int licReqNums);
int hglm_keep(char* featureName, char* featureVersion);
int hglm_release(char* featureName, char* featureVersion);

#endif

#ifdef __cplusplus
}
#endif

#endif
